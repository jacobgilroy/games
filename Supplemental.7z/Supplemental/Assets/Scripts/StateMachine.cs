﻿using UnityEngine;
using System.Collections;
using System;

public class StateMachine : MonoBehaviour {

    int greenTime;
    int yellowTime;
    int redTime;

    /*public Enum state
    {
        get
        {
            return state;
        }

        set
        {
            state = value;
        }
    }
    */

    // Use this for initialization
    void Start () {
	
	}

    void ChangeState()
    {

    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
