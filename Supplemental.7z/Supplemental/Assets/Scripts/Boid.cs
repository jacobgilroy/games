﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Boid : MonoBehaviour {

    List<SteeringBehaviour> behaviours = new List<SteeringBehaviour>();
    Vector3 force = Vector3.zero;
    Vector3 acceleration = Vector3.zero;
    Vector3 velocity = Vector3.zero;
    float mass = 1.0f;
    float maxSpeed = 5.0f;

	// Use this for initialization
	void Start () {

        SteeringBehaviour[] behaves = GetComponents<SteeringBehaviour>();

        foreach(SteeringBehaviour b in behaves)
        {
            behaviours.Add(b);
        }
	
	}

    Vector3 SeekForce(Vector3 target)
    {
        Vector3 toTarget = target - transform.position;
        float distance = toTarget.magnitude;
        Vector3 desiredVelocity = distance * Time.deltaTime * toTarget;

        return desiredVelocity - velocity;
    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
