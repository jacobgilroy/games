﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;

public class Spawner : MonoBehaviour {

    public GameObject carPrefab = new GameObject();
    public GameObject trafficLightPrefab = new GameObject();
    public List<GameObject> trafficLights = new List<GameObject>(); 
    float radius = 10.0f;
    int numLights = 10;

	// Use this for initialization
	void Start () {

        //set the position to the origin:
        transform.position = Vector3.zero;
        trafficLightPrefab.transform.position = transform.position;
        carPrefab.transform.position = transform.position;
	
	}

    void Awake()
    {
        //generate + instantiate the traffic lights:

        for (int i = 0; i < numLights; i++)
        {
            trafficLights.Add(Instantiate(trafficLightPrefab));
        }

        
    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
